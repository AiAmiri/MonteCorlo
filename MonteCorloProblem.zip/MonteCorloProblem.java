import java.util.*;
public class MonteCarlo {
	public static void main(String[] args) {
	System.out.print("enter number of random point : ");
	Scanner input=new Scanner(System.in);
	Random r=new Random();
	double pointNum=input.nextDouble();
	double x,y,c,k=1,cN=1;
	while(k <=pointNum){
	x=r.nextDouble()*2-1;
	y=r.nextDouble()*2-1;
	c=Math.sqrt(x*x+y*y);
	if ( c  <= 1)
	cN++;
	k++;
	}
	System.out.println("Pi value = "+ 4.0d*cN/pointNum);
	}
}